clear all %Cada vez que corra el programa que se elimine todo lo existente
close all
clc

%[varargout,NumeroFunc,numPoblacion,iteraciones] = gui_proyecto();
%disp ('NumeroFunc3434343')
%disp (NumeroFunc)

%NumeroFunc=12;
%numVariables = 4;%se utiliza cuando la f(x) tiene details.MaxDimensions = 0
%iteraciones=3000;
%desvTol = 0.00001;% tolerancia de desvicación 
%numPoblacion = 4;%Numero de elementos en la poblacion
%[minimo,sol]= AGFinal(NumeroFunc,numPoblacion,numVariables,iteraciones,desvTol);
%disp('ultimo calculado');
%disp(minimo);

