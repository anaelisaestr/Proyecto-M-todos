function [sMin,sol,solProm,solPeor]= AGFinal(NoF,numPob,numVar,numIter,desvTol)
%function [sMin,sol]= AG (limInf,limSup,minFuncion,numVar,numPob,numIter)
%sMin:solucion minima obtenida de f(Xo)
%sol: matriz que almacena los valores de sMin de cada iteración
%NoF: Numero de función del archivo bfm.m
%numPob: Numero de elementos de la poblacion 
%numVar: Numero de variables por elemento (X1,X2,X3...Xn)
%numIter: Numero de iteraciones maximas
%desvTol: Tolerancia aceptada en la desviacion del valor obtenido de f(Xo) y
% el valor de Foptimum de la función
clc;
limSup = zeros;
limInf = zeros;
[F,details] = bfm(NoF,[1,1,1,1]);
%% DIMENSIONES DE LAS FUNCIONES
numDim = details.MaxDimensions;% obtiene el numero de dimensiones de la funcion
if numDim >=2
      for i=1:numDim
         limInf(i)=details.Constraints(i,1);%limite inferior de la dimension x(i)
         limSup(i)=details.Constraints(i,2);% limite superior de la dimension x(i)
      end
else 
    limInf(1)= details.Constraints(1,1);
    limSup(1)= details.Constraints(1,2);
end
disp(limInf);
disp(limSup);
minFuncion = details.Foptimum;%valor minimo de la funcion f(x)
poblacion=zeros; %matriz que contiene los valores de las variables de cada elemneto
                 % poblacion(m,n): m es el numero de variables del
                 % elemento n (cada columna es un elemento con m variables)
cont = 1; % contador de iteraciones
sol(numIter)=zeros; % matriz que almacena las soluciones de cada iteracion
s(numPob)=zeros;% matriz que guarda los valores de f(x)
distSol = 100;% se le asigna un valor mayor al minimo de la funcion para que arranque el programa
sMin =10;
solPeor(numIter)=zeros;%matriz para guardar el peor valor
solProm(numIter)=zeros;%matriz para guadar el promedio

%% POBLACION INICIAL
% genera Poblacion inicial aleatoriamente en un rango entre limite inferior y limite superior
if numDim >=2
    numVar=numDim;
    for j=1:numPob
       for i=1:numVar
         poblacion(i,j)= limInf(i) + (limSup(i)-limInf(i))*rand; 
         %disp(poblacion);%Muestra la poblacion inicial
       end
    end
else
    poblacion = limInf(1) + (limSup(1)-limInf(1))*rand (numVar,numPob);
end    
disp(poblacion);%Muestra la poblacion inicial  

%% EMPIEZA WHILE
while distSol > desvTol && cont < numIter

if sMin == minFuncion
        break
end
disp('inicio de ciclo')
%% EVALUACION
for i=1:numPob
s(i)=bfm(NoF,poblacion(:,i));% s = f(elemento(i));%Evalua la función con variables del elemento "i"columna,de la población
%disp(s);
end
 %   s = f(elemento(i));%Evalua la función con las variables del elemento "i" de la población
disp(s);%Muestra la solución f(x) de cada elemento

%% PROCESO DE FITNESS
%Identifica la solucion menos favorable, valor mayor de f(x)
[sMax,iMax]= max (s);% obtiene el valor mayor de la matriz "s" o (f(x))
disp (sMax);% muestra el valor mayor de la función f(x)
disp (iMax); %Muestra el numero de elemento con la solucion menos favorable
solPeor(cont) = sMax;%Guarda la peor solucion 

%Envia el elemento con la solucion menos favorable a la columna final de la poblacion
for i=1:numVar
    temp = poblacion(i,numPob);
   poblacion(i,numPob) = poblacion(i,iMax);
    poblacion(i,iMax) = temp;
end
disp('cambia elemento con solucion menos favorable al final de la poblacion')
disp(poblacion);% Muestra poblacion con el elemento que da f(x) mayor. en la ultima columna

%% PROCESO DE SELECCION
%Se reemplaza el elemento menos favorable de la población ( f(x) mayor ) por
%otro elemento de la poblacion
for i=1:numVar
    poblacion(i,numPob) = poblacion (i,1);
end
%disp(poblacion);

%% PROCESO DE CRUCE
% Combina de 2 en 2 elementos, intercambiando la mitad de sus variables
% combina los elementos 1 y 2, 3 y 4, 5 y 6, ...
n = round (numVar/2) +1;
for j=1:2:numPob -1
    for i=n:numVar
    temp2 = poblacion(i,j);
    poblacion(i,j) = poblacion(i,j+1);
    poblacion(i,j+1) = temp2;
    end
end
%disp(n);
%disp(solucion);

%% PROCESO DE MUTACIÓN
%Se cambia el valor de una de las variables de cada elemento 
for j=1:numPob
      renglon = randi([1 numVar]); % selecciona un valor del elemento aleatoriamente
       muta = -0.5 + (1)*rand; % obtiene el valor delta a incrementar o disminuir (aleatorio entre -0.5 y 0.5)
      if minFuncion == 0
           if sMin< 1  % si el resultado de f(x)<1, decrementa el delta de la mutación, proporcionalmente a resultado de f(x)
              muta = muta*sMin;
           end
      end
      poblacion(renglon,j)= poblacion(renglon,j)-muta;% reliza la mutación de la variable
end
%disp(mayor);
%disp(solucion);
%Obtiene la solucion que minimiza f(x)
%cont=cont+1;%contador de iteraciones
%s = funcion(poblacion); %evalua f(x) de la nueva poblacion
for i=1:numPob
s(i)=bfm(NoF,poblacion(:,i));% s = f(elemento(i));%Evalua la función con las variables del elemento "i" de la población
%disp(s);
end
[sMin,iMin]= min (s); % obtiene el valor minimo de la solucion de f(x) y su posición en el vector
sol(cont)= sMin; % guarda el resultado de la iteracion en la matriz de soluciones "sol"
solProm(cont) = (solPeor(cont) + sol(cont))/2; %Calcula el promedio de las soluciones 

%% CALCULO DE LA DISTANCIA (diferencia entre el valor optimo(Foptimum) de la funcion y la
%solucion obtenida por el algoritmo genetico
if sMin < 0
   if sMin > minFuncion
    distSol= abs(minFuncion - sMin);
   else 
       distSol= minFuncion - sMin;
   end
end
if sMin > 0
        distSol = sMin- minFuncion;
end


disp(poblacion);
disp(sMin);disp(iMin);
disp(cont);
disp (distSol);
cont=cont + 1

%minCalc= min(sol);
disp ('ultima solución calculada: f(x)');disp (sMin);
disp('numero de iteraciones:');disp(cont-1);
disp('valor optimo de f(Xo):');disp(minFuncion);


%% Despliega grafica de f(x) ANIMADA

for i=1:cont
T(i)=sol(i);
plot(T);
xlabel('No. de Iteracion')
ylabel('Valor de f(x)'); grid on; 
drawnow;
end


%% Termina while
end

%% Despliega grafica de f(x)--->MEJOR/PEOR/PROMEDIO
figure(2)
plot(sol);
hold on
plot(solProm)
plot(solPeor)
xlabel('No. de Iteracion')
ylabel('Valor de f(x)'); grid on; 
xlim([1 cont])
legend('Mejor','Promedio','Peor');
hold off


